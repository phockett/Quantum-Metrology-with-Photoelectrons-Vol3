Quantum Metrology with Photoelectrons Volume 3: Analysis methodologies
An open source executable book by Paul Hockett with Varun Makhija.
31st July 2023

This archive contains sample fitting datasets to accompany the text.

For more details see:

- Git repository for the book, https://github.com/phockett/Quantum-Metrology-with-Photoelectrons-Vol3
- HTML version, https://phockett.github.io/Quantum-Metrology-with-Photoelectrons-Vol3